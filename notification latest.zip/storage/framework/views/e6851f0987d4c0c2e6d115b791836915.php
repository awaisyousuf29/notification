<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\notification\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>